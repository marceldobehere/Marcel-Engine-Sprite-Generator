﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using System.IO;
using Object = System.Object;

namespace Marcel_Engine_Sprite_Editor
{

    class Program
    {
        static void Main()
        {
            SpriteEditorCode code = new SpriteEditorCode();

            code.Editor();

            Console.Clear();
            Console.WriteLine("End.");
            Console.ReadLine();
        }
    }
    class SpriteEditorCode
    {
        public MainEngine engine;
        public ObjectMiscData obj;
        public Input inp;

        public Scene DrawScene;
        public Scene MenuScene;

        public Engine.Object Cursor, Sprite, ToolText, DrawTitle, CurrentColourText, CurrentColourshow, CurrentBehindColourshow;

        public Engine.Object MenuTitle, MenuCursor, MenuSelectionClearImage, MenuSaveImage, MenuLoadImage, MenuHelp, MenuResize;
        public int SelectedTool { get; set; }

        public readonly string[] SelectedToolNames = { "Pencil", "Line", "Rectangle", "Bucket", "Eraser", "Text" };

        (int x, int y) Offset;

        (int x, int y) MaxSpriteSize;

        public (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) current_pixel;

        public bool InMenu, SelectTool;

        public int BackroundColour;

        public void Editor()
        {
            BackroundColour = 0;
            MaxSpriteSize = (100, 100);
            Offset = (0, 5);

            engine = new MainEngine((500, 500, 2), true, "Consolas");
            obj = new ObjectMiscData();
            inp = new Input();

            PrepareMenuScene();

            PrepareDrawScene();

            InMenu = false;

            while (true)
            {
                if (InMenu)
                {
                    MenuLoop();
                }
                else
                {
                    DrawLoop();
                }
            }

        }

        private void PrepareDrawScene()
        {
            SelectTool = false;
            SelectedTool = 0;
            DrawScene = new Scene();
            engine.ChangeActiveScene(DrawScene);

            Sprite = new Engine.Object();
            Sprite.ActiveObjectType = 1;
            Sprite.Layer = 1;
            Sprite.Player.ActiveSprite = new Graphics.Sprite();
            engine.AddObjectToScene(Sprite);
            Sprite.Position = Offset;

            current_pixel = ((char)'O', (0, 10, 0), (0, 0));

            Cursor = new Engine.Object();
            Cursor.ActiveObjectType = 1;
            Cursor.Layer = 2;
            Cursor.Player.ActiveSprite = new Graphics.Sprite();
            Cursor.Player.ActiveSprite.ImageData.Add(current_pixel);
            engine.AddObjectToScene(Cursor);
            Cursor.Position = Offset;


            DrawTitle = new Engine.Object();
            DrawTitle.ActiveObjectType = 2;
            DrawTitle.Layer = 1;
            DrawTitle.Text.Text = "Marcel Engine - Sprite Editor - Editor";
            engine.AddObjectToScene(DrawTitle);
            DrawTitle.Update();

            CurrentColourText = new Engine.Object();
            CurrentColourText.ActiveObjectType = 2;
            CurrentColourText.Layer = 1;
            CurrentColourText.Text.Text = "Current Colour: X (Behind: X )";
            CurrentColourText.Position = (0, 2);
            engine.AddObjectToScene(CurrentColourText);
            CurrentColourText.Update();

            ToolText = new Engine.Object();
            ToolText.ActiveObjectType = 2;
            ToolText.Layer = 1;
            ToolText.Text.Text = $"Tool: {SelectedToolNames[SelectedTool]}";
            ToolText.Position = (0, 3);
            engine.AddObjectToScene(ToolText);
            ToolText.Update();

            CurrentColourshow = new Engine.Object();
            CurrentColourshow.ActiveObjectType = 1;
            CurrentColourshow.Layer = 3;
            CurrentColourshow.Player.ActiveSprite = new Graphics.Sprite();
            CurrentColourshow.Player.ActiveSprite.ImageData.Add(current_pixel);
            engine.AddObjectToScene(CurrentColourshow);
            CurrentColourshow.Position = (16, 2);

            CurrentBehindColourshow = new Engine.Object();
            CurrentBehindColourshow.ActiveObjectType = 1;
            CurrentBehindColourshow.Layer = 3;
            CurrentBehindColourshow.Player.ActiveSprite = new Graphics.Sprite();
            CurrentBehindColourshow.Player.ActiveSprite.ImageData.Add(current_pixel);
            engine.AddObjectToScene(CurrentBehindColourshow);
            CurrentBehindColourshow.Position = (27, 2);


        }


        private void PrepareMenuScene()
        {
            MenuScene = new Scene();
            engine.ChangeActiveScene(MenuScene);
            MenuTitle = new Engine.Object();
            MenuTitle.ActiveObjectType = 2;
            MenuTitle.Layer = 0;
            MenuTitle.Text.Text = "Marcel Engine - Sprite Editor - Menu";
            MenuTitle.Position = (0, 0);
            engine.AddObjectToScene(MenuTitle);

            MenuSaveImage = new Engine.Object();
            MenuSaveImage.ActiveObjectType = 2;
            MenuSaveImage.Layer = 0;
            MenuSaveImage.Text.Text = "Export Image as .mesf File";
            MenuSaveImage.Position = (2, 2);
            engine.AddObjectToScene(MenuSaveImage);

            MenuLoadImage = new Engine.Object();
            MenuLoadImage.ActiveObjectType = 2;
            MenuLoadImage.Layer = 0;
            MenuLoadImage.Text.Text = "Import Image as .mesf File";
            MenuLoadImage.Position = (2, 3);
            engine.AddObjectToScene(MenuLoadImage);

            MenuSelectionClearImage = new Engine.Object();
            MenuSelectionClearImage.ActiveObjectType = 2;
            MenuSelectionClearImage.Layer = 0;
            MenuSelectionClearImage.Text.Text = "Delete Image";
            MenuSelectionClearImage.Position = (2, 4);
            engine.AddObjectToScene(MenuSelectionClearImage);

            MenuResize = new Engine.Object();
            MenuResize.ActiveObjectType = 2;
            MenuResize.Layer = 0;
            MenuResize.Text.Text = "Resize Image";
            MenuResize.Position = (2, 5);
            engine.AddObjectToScene(MenuResize);

            MenuHelp = new Engine.Object();
            MenuHelp.ActiveObjectType = 2;
            MenuHelp.Layer = 0;
            MenuHelp.Text.Text = "Help";
            MenuHelp.Position = (2, 6);
            engine.AddObjectToScene(MenuHelp);


            MenuCursor = new Engine.Object();
            MenuCursor.ActiveObjectType = 1;
            MenuCursor.Layer = 1;
            MenuCursor.Player.ActiveSprite = new Graphics.Sprite();
            MenuCursor.Player.ActiveSprite.ImageData.Add(((char)'>', (0, 0, 14), (0, 0)));
            engine.AddObjectToScene(MenuCursor);
            MenuCursor.Position = (0, 2);
        }

        private void UpdateDrawingInformation()
        {
            CurrentColourshow.Player.ActiveSprite.ImageData[0] = (current_pixel.chr, (current_pixel.col), (0, 0));
            CurrentColourshow.Update();
            (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) temppixel = GetPixelAt(current_pixel.pos).pixel;
            CurrentBehindColourshow.Player.ActiveSprite.ImageData[0] = (temppixel.chr, (temppixel.col), (0, 0));
            CurrentBehindColourshow.Update();

            ToolText.Text.Text = $"Tool: {SelectedToolNames[SelectedTool]}";
            ToolText.Update();
        }

        private void MoveMode()
        {
            Movement();

            if (inp.KeyPressed(Input.Key.One))
            {
                if (current_pixel.col.bri > 0)
                {
                    current_pixel.col.bri--;
                }
                System.Threading.Thread.Sleep(50);
            }
            if (inp.KeyPressed(Input.Key.Two))
            {
                if (current_pixel.col.bri < 2)
                {
                    current_pixel.col.bri++;
                }
                System.Threading.Thread.Sleep(50);
            }
            if (inp.KeyPressed(Input.Key.Three))
            {
                if (current_pixel.col.col_b > 0)
                {
                    current_pixel.col.col_b--;
                }
                System.Threading.Thread.Sleep(50);
            }
            if (inp.KeyPressed(Input.Key.Four))
            {
                if (current_pixel.col.col_b < 15)
                {
                    current_pixel.col.col_b++;
                }
                System.Threading.Thread.Sleep(50);
            }
            if (inp.KeyPressed(Input.Key.Five))
            {
                if (current_pixel.col.col_f > 0)
                {
                    current_pixel.col.col_f--;
                }
                System.Threading.Thread.Sleep(50);
            }
            if (inp.KeyPressed(Input.Key.Six))
            {
                if (current_pixel.col.col_f < 15)
                {
                    current_pixel.col.col_f++;
                }
                System.Threading.Thread.Sleep(50);
            }
            if (inp.KeyPressed(Input.Key.Seven))
            {
                if (BackroundColour > 0)
                {
                    BackroundColour--;
                    engine.Display.BackroundColour = BackroundColour;
                    engine.ChangeActiveScene(DrawScene);
                }
                System.Threading.Thread.Sleep(100);
            }
            if (inp.KeyPressed(Input.Key.Eight))
            {
                if (BackroundColour < 15)
                {
                    BackroundColour++;
                    engine.Display.BackroundColour = BackroundColour;
                    engine.ChangeActiveScene(DrawScene);
                }
                System.Threading.Thread.Sleep(100);
            }


            UpdateDrawingInformation();

            if (inp.KeyPressed(Input.Key.Zero))
            {
                ClearInputBuffer();
                Console.SetCursorPosition(Cursor.Position.x * 2, Cursor.Position.y);
                ConsoleKeyInfo temp = Console.ReadKey();
                if (temp.Key == ConsoleKey.Enter)
                {
                    current_pixel.chr = (char)0;
                }
                else
                {
                    current_pixel.chr = (char)temp.KeyChar;
                }
                System.Threading.Thread.Sleep(100);
            }

            if (inp.KeyPressed(Input.Key.C))
            {
                current_pixel = GetPixelAt(current_pixel.pos).pixel;
            }

            if (inp.KeyPressed(Input.Key.Spacebar))
            {
                SpaceTestTools();
            }



            if (inp.KeyPressed(Input.Key.M))
            {
                MenuResize.Text.Text = $"Resize Image {MaxSpriteSize.x}x{MaxSpriteSize.y}";
                InMenu = true;
                engine.Display.BackroundColour = 0;
                engine.ChangeActiveScene(MenuScene);
                System.Threading.Thread.Sleep(50);
            }

            if (inp.KeyPressed(Input.Key.P))
            {
                SelectTool = true;
                System.Threading.Thread.Sleep(100);
            }


            engine.RenderFrame(20);
            Console.SetCursorPosition(Cursor.Position.x * 2, Cursor.Position.y);
            Console.CursorVisible = true;
        }

        private void Movement()
        {
            if (inp.KeyPressed(Input.Key.RightArrow) || inp.KeyPressed(Input.Key.D))
            {
                if (Cursor.Position.x < MaxSpriteSize.x + Offset.x - 1)
                {
                    Cursor.MoveX(1);
                }
            }
            if (inp.KeyPressed(Input.Key.LeftArrow) || inp.KeyPressed(Input.Key.A))
            {
                if (Cursor.Position.x > Offset.x)
                {
                    Cursor.MoveX(-1);
                }
            }
            if (inp.KeyPressed(Input.Key.DownArrow) || inp.KeyPressed(Input.Key.S))
            {
                if (Cursor.Position.y < MaxSpriteSize.y + Offset.y - 1)
                {
                    Cursor.MoveY(1);
                }
            }
            if (inp.KeyPressed(Input.Key.UpArrow) || inp.KeyPressed(Input.Key.W))
            {
                if (Cursor.Position.y > Offset.y)
                {
                    Cursor.MoveY(-1);
                }
            }
            current_pixel.pos = ((Cursor.Position.x - Offset.x), (Cursor.Position.y - Offset.y));

            Cursor.Player.ActiveSprite.ImageData[0] = CurrentColourshow.Player.ActiveSprite.ImageData[0];

            Cursor.Update();
        }
        private void PlacePixel()
        {
            int index = GetPixelAt(current_pixel.pos).index;
            if (index == -1)
            {
                Sprite.Player.ActiveSprite.ImageData.Add(current_pixel);
            }
            else
            {
                Sprite.Player.ActiveSprite.ImageData[index] = current_pixel;
            }
            Sprite.Update();
        }


        private void SpaceTestTools()
        {
            if (SelectedTool == 0)
            {
                PlacePixel();
            }
            if (SelectedTool == 1)
            {
                (int x, int y) pos_1 = current_pixel.pos;
                PlacePixel();
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                while (!inp.KeyPressed(Input.Key.Spacebar))
                {
                    Movement();
                    UpdateDrawingInformation();
                    engine.RenderFrame(20);
                    Console.SetCursorPosition(Cursor.Position.x * 2, Cursor.Position.y);
                    Console.CursorVisible = true;
                }
                (int x, int y) pos_2 = current_pixel.pos;
                PlacePixel();

                DrawLine(pos_1, pos_2);

                UpdateDrawingInformation();
                engine.RenderFrame(20);
                Console.SetCursorPosition(Cursor.Position.x * 2, Cursor.Position.y);
                Console.CursorVisible = true;
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
            }
            if (SelectedTool == 2)
            {
                (int x, int y) pos_1 = current_pixel.pos;
                PlacePixel();
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                while (!inp.KeyPressed(Input.Key.Spacebar))
                {
                    Movement();
                    UpdateDrawingInformation();
                    engine.RenderFrame(20);
                    Console.SetCursorPosition(Cursor.Position.x * 2, Cursor.Position.y);
                    Console.CursorVisible = true;
                }
                (int x, int y) pos_2 = current_pixel.pos;
                PlacePixel();

                DrawLine((pos_1.x, pos_1.y), (pos_2.x, pos_1.y));
                DrawLine((pos_2.x, pos_1.y), (pos_2.x, pos_2.y));
                DrawLine((pos_2.x, pos_2.y), (pos_1.x, pos_2.y));
                DrawLine((pos_1.x, pos_2.y), (pos_1.x, pos_1.y));

                UpdateDrawingInformation();
                engine.RenderFrame(20);
                Console.SetCursorPosition(Cursor.Position.x * 2, Cursor.Position.y);
                Console.CursorVisible = true;
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
            }
            if (SelectedTool == 3)
            {
                fillcol = GetPixelAt(current_pixel.pos);
                (int x, int y) pos = current_pixel.pos;
                if ((fillcol.pixel.col != current_pixel.col) || (fillcol.pixel.chr != current_pixel.chr) || (fillcol.index == -1))
                {
                    FillSprite(current_pixel.pos);
                }
                current_pixel.pos = pos;
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
            }
            if (SelectedTool == 4)
            {
                int index = GetPixelAt(current_pixel.pos).index;
                if (index != -1)
                {
                    Sprite.Player.ActiveSprite.ImageData.RemoveAt(index);
                }
                Sprite.Update();
            }
            if (SelectedTool == 5)
            {
                Console.SetCursorPosition(Cursor.Position.x * 2, Cursor.Position.y);
                ClearInputBuffer();
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;
                string text = Console.ReadLine();
                fillcol.pixel = current_pixel;
                foreach (char X in text)
                {
                    current_pixel.chr = X;
                    PlacePixel();
                    current_pixel.pos.x++;
                }
                current_pixel = fillcol.pixel;
                //current_pixel.chr = text[0];
                Sprite.Update();
            }
        }
        private ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel, int index) fillcol;
        private void FillSprite((int x, int y) pos)
        {
            int counter = 0;
            List<(int x, int y)> positions = new List<(int x, int y)>();
            positions.Add(pos);

            while (positions.Count != 0)
            {

                counter++;
                if (counter % 200 == 0)
                {
                    engine.RenderFrame(-1);
                }

                (int x, int y) tpos = positions.Last();
                positions.RemoveAt(positions.Count - 1);
                if (!((tpos.x < 0) || (tpos.y < 0) || (tpos.x >= MaxSpriteSize.x) || (tpos.y >= MaxSpriteSize.y)))
                {
                    ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel, int index) pixel = GetPixelAt(tpos);
                    if ((fillcol.pixel.col == pixel.pixel.col) && (fillcol.pixel.chr == pixel.pixel.chr) && (((pixel.index == -1) && (fillcol.index == -1)) || ((pixel.index != -1) && (fillcol.index != -1))))
                    {
                        current_pixel.pos = tpos;
                        PlacePixel();
                        //engine.RenderFrame(10);
                        (int x, int y) pos2 = tpos;
                        pos2.x += 1;
                        if (!((pos2.x < 0) || (pos2.y < 0) || (pos2.x >= MaxSpriteSize.x) || (pos2.y >= MaxSpriteSize.y)))
                        {
                            pixel = GetPixelAt(pos2);
                            if ((fillcol.pixel.col == pixel.pixel.col) && (fillcol.pixel.chr == pixel.pixel.chr) && (((pixel.index == -1) && (fillcol.index == -1)) || ((pixel.index != -1) && (fillcol.index != -1))))
                            {
                                if (!positions.Contains(pos2))
                                {
                                    positions.Add(pos2);
                                }
                            }
                        }
                        pos2.x -= 2;
                        if (!((pos2.x < 0) || (pos2.y < 0) || (pos2.x >= MaxSpriteSize.x) || (pos2.y >= MaxSpriteSize.y)))
                        {
                            pixel = GetPixelAt(pos2);
                            if ((fillcol.pixel.col == pixel.pixel.col) && (fillcol.pixel.chr == pixel.pixel.chr) && (((pixel.index == -1) && (fillcol.index == -1)) || ((pixel.index != -1) && (fillcol.index != -1))))
                            {
                                if (!positions.Contains(pos2))
                                {
                                    positions.Add(pos2);
                                }
                            }
                        }
                        pos2.x += 1;
                        pos2.y += 1;
                        if (!((pos2.x < 0) || (pos2.y < 0) || (pos2.x >= MaxSpriteSize.x) || (pos2.y >= MaxSpriteSize.y)))
                        {
                            pixel = GetPixelAt(pos2);
                            if ((fillcol.pixel.col == pixel.pixel.col) && (fillcol.pixel.chr == pixel.pixel.chr) && (((pixel.index == -1) && (fillcol.index == -1)) || ((pixel.index != -1) && (fillcol.index != -1))))
                            {
                                if (!positions.Contains(pos2))
                                {
                                    positions.Add(pos2);
                                }
                            }
                        }
                        pos2.y -= 2;
                        if (!((pos2.x < 0) || (pos2.y < 0) || (pos2.x >= MaxSpriteSize.x) || (pos2.y >= MaxSpriteSize.y)))
                        {
                            pixel = GetPixelAt(pos2);
                            if ((fillcol.pixel.col == pixel.pixel.col) && (fillcol.pixel.chr == pixel.pixel.chr) && (((pixel.index == -1) && (pixel.index == -1)) || ((pixel.index != -1) && (pixel.index != -1))))
                            {
                                if (!positions.Contains(pos2))
                                {
                                    positions.Add(pos2);
                                }
                            }
                        }
                    }

                }
            }
        }



        private void DrawLine((int x, int y) pos_1, (int x, int y) pos_2)
        {
            (int x, int y) starting_pos;
            (int x, int y) ending_pos;
            if (Math.Abs(pos_1.x - pos_2.x) >= Math.Abs(pos_1.y - pos_2.y))
            {
                if (pos_1.x <= pos_2.x)
                {
                    starting_pos = pos_1;
                    ending_pos = pos_2;
                }
                else
                {
                    starting_pos = pos_2;
                    ending_pos = pos_1;
                }
                double y_move = (ending_pos.y - starting_pos.y) / (double)Math.Abs(pos_1.x - pos_2.x);
                double t_y = starting_pos.y;
                for (double t_x = starting_pos.x; t_x <= ending_pos.x; t_x++)
                {
                    current_pixel.pos = ((int)Math.Round(t_x), (int)Math.Round(t_y));
                    PlacePixel();
                    t_y += y_move;
                }
            }
            else
            {
                if (pos_1.y <= pos_2.y)
                {
                    starting_pos = pos_1;
                    ending_pos = pos_2;
                }
                else
                {
                    starting_pos = pos_2;
                    ending_pos = pos_1;
                }
                double x_move = (ending_pos.x - starting_pos.x) / (double)Math.Abs(pos_1.y - pos_2.y);
                double t_x = starting_pos.x;
                for (double t_y = starting_pos.y; t_y <= ending_pos.y; t_y++)
                {
                    current_pixel.pos = ((int)Math.Round(t_x), (int)Math.Round(t_y));
                    PlacePixel();
                    t_x += x_move;
                }
            }
        }



        private void SelectToolMode()
        {
            UpdateDrawingInformation();


            if (inp.KeyPressed(Input.Key.RightArrow))
            {
                SelectedTool = (SelectedTool + 1) % SelectedToolNames.Length;
                System.Threading.Thread.Sleep(100);
            }
            if (inp.KeyPressed(Input.Key.LeftArrow))
            {
                SelectedTool = (SelectedTool - 1 + SelectedToolNames.Length) % SelectedToolNames.Length;
                System.Threading.Thread.Sleep(100);
            }

            if (inp.KeyPressed(Input.Key.P) || inp.KeyPressed(Input.Key.Enter))
            {
                SelectTool = false;
                System.Threading.Thread.Sleep(100);
            }


            engine.RenderFrame(20);
            Console.SetCursorPosition(11 + (SelectedToolNames[SelectedTool].Length * 2), 3);
            Console.CursorVisible = true;
        }


        private void DrawLoop()
        {
            if (!SelectTool)
            {
                MoveMode();
            }
            else
            {
                SelectToolMode();
            }
        }

        private ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel, int index) GetPixelAt((int x, int y) pos)
        {
            int index = -1;
            for (int i = 0; i < Sprite.Player.ActiveSprite.ImageData.Count; i++)
            {
                if (Sprite.Player.ActiveSprite.ImageData[i].pos == pos)
                {
                    index = i;
                    break;
                }
            }
            if (index == -1)
            {
                return (((char)0, (0, 0, 0), (0, 0)), (-1));
            }
            else
            {
                return (Sprite.Player.ActiveSprite.ImageData[index], index);
            }

        }
        private void ClearInputBuffer()
        {
            System.Threading.Thread.Sleep(20);
            while (Console.KeyAvailable)
                Console.ReadKey(true);
            System.Threading.Thread.Sleep(20);
        }


        private void SaveSprite(string filename)
        {
            /*
                Fileformat is:
                MESFVER 2
                (x_1)|(y_1)|(x_2)|(y_2) // not needed lol.
                (char)|(brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (char)|(brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (char)|(brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (char)|(brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                ...
                */

            StreamWriter writer = new StreamWriter(filename);
            writer.WriteLine("MESFVER 2");
            Graphics.Sprite tempsprite = Sprite.Player.ActiveSprite;
            writer.WriteLine($"{tempsprite.Border.x1}|{tempsprite.Border.y1}|{tempsprite.Border.x2}|{tempsprite.Border.y2}");
            foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel in tempsprite.ImageData)
            {
                writer.WriteLine($"{pixel.chr}|{pixel.col.bri}|{pixel.col.col_b}|{pixel.col.col_f}|{pixel.pos.x}|{pixel.pos.y}");
            }
            writer.Close();
        }

        private void LoadSprite(string filename)
        {
            Sprite.Player.ActiveSprite = new Graphics.Sprite(filename, false);
            Sprite.Update();
        }


        private void MenuLoop()
        {
            if (inp.KeyPressed(Input.Key.M))
            {
                InMenu = false;
                engine.Display.BackroundColour = BackroundColour;
                engine.ChangeActiveScene(DrawScene);
                System.Threading.Thread.Sleep(50);
            }
            if (inp.KeyPressed(Input.Key.DownArrow) || inp.KeyPressed(Input.Key.S))
            {
                if (MenuCursor.Position.y < 10)
                {
                    MenuCursor.MoveY(1);
                }
            }
            if (inp.KeyPressed(Input.Key.UpArrow) || inp.KeyPressed(Input.Key.W))
            {
                if (MenuCursor.Position.y > 2)
                {
                    MenuCursor.MoveY(-1);
                }
            }
            if (inp.KeyPressed(Input.Key.Spacebar) || inp.KeyPressed(Input.Key.Enter))
            {
                string filename;
                switch (MenuCursor.Position.y - 2)
                {
                    case 0:
                        MenuSaveImage.Text.Text = "Export Image as .mesf File:";
                        MenuSaveImage.Text.TextColour = (1, 10);
                        MenuSaveImage.Update();
                        engine.RenderFrame(10);
                        ClearInputBuffer();
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.SetCursorPosition(58, 2);
                        filename = Console.ReadLine();
                        MenuSaveImage.Text.Text = "Export Image as .mesf File";
                        MenuSaveImage.Text.TextColour = (0, 14);
                        engine.ChangeActiveScene(MenuScene);
                        //engine.RenderFrame(10);
                        SaveSprite(filename);
                        break;

                    case 1:
                        MenuLoadImage.Text.Text = "Import Image as .mesf File:";
                        MenuLoadImage.Text.TextColour = (1, 10);
                        MenuLoadImage.Update();
                        engine.RenderFrame(10);
                        ClearInputBuffer();
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.SetCursorPosition(58, 3);
                        filename = Console.ReadLine();
                        MenuLoadImage.Text.Text = "Import Image as .mesf File";
                        MenuLoadImage.Text.TextColour = (0, 14);
                        engine.ChangeActiveScene(MenuScene);
                        //engine.RenderFrame(10);
                        LoadSprite(filename);
                        break;


                    case 2:
                        engine.ChangeActiveScene(DrawScene);
                        engine.RenderFrame(3);
                        engine.RemoveObjectFromScene(Sprite);
                        engine.RenderFrame(10);
                        Sprite.Player.ActiveSprite = new Graphics.Sprite();
                        engine.AddObjectToScene(Sprite);
                        engine.RenderFrame(10);
                        engine.ChangeActiveScene(MenuScene);
                        engine.RenderFrame(5);
                        break;

                    case 3:
                        (int x, int y) new_size = (0,0);
                        MenuResize.Text.Text = "Enter X-Size:";
                        MenuResize.Text.TextColour = (1, 10);
                        MenuResize.Update();
                        engine.RenderFrame(10);
                        ClearInputBuffer();
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.SetCursorPosition(30, 5);
                        new_size.x = int.Parse(Console.ReadLine());
                        engine.ChangeActiveScene(MenuScene);
                        MenuResize.Text.Text = "Enter Y-Size:";
                        MenuResize.Text.TextColour = (1, 10);
                        MenuResize.Update();
                        engine.RenderFrame(10);
                        ClearInputBuffer();
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.SetCursorPosition(30, 5);
                        new_size.y = int.Parse(Console.ReadLine());
                        if (new_size.x < 1)
                        {
                            new_size.x = 1;
                        }
                        if (new_size.x > 400)
                        {
                            new_size.x = 400;
                        }
                        if (new_size.y < 1)
                        {
                            new_size.y = 1;
                        }
                        if (new_size.y > 400)
                        {
                            new_size.y = 400;
                        }
                        MaxSpriteSize = new_size;
                        MenuResize.Text.Text = $"Resize Image {MaxSpriteSize.x}x{MaxSpriteSize.y}";
                        MenuResize.Text.TextColour = (0, 14);
                        engine.ChangeActiveScene(MenuScene);
                        Cursor.Position = Offset;
                        current_pixel.pos = (0,0);
                        break;

                    case 4:
                        ClearInputBuffer();

                        ShowHelpScreen();

                        Console.Clear();
                        engine.ChangeActiveScene(MenuScene);
                        engine.RenderFrame(5);
                        break;
                }
                System.Threading.Thread.Sleep(100);
            }
            Console.CursorVisible = false;
            engine.RenderFrame(15);
        }

        public void ShowHelpScreen()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.WriteLine("Marcel Engine - Sprite Editor - Help\n");

            Console.WriteLine("Changing The Pixel Colour:\n");
            Console.WriteLine("Use 1, 2 to change the pixel brightness. (only works if the Pixel char is nothing)");
            Console.WriteLine("Use 3, 4 to change the Backround colour.");
            Console.WriteLine("Use 5, 6 to change the Foreround colour.");
            Console.WriteLine("Press 0 Change the char. (Press 0 then the char or just press enter to make it nothing.)");
            Console.WriteLine("Press C to use the colour you are currently on.");

            Console.WriteLine("\nChanging The Backround Colour:\n");
            Console.WriteLine("Use 7, 8 to change the Backround colour.");

            Console.WriteLine("\nMovement:\n");
            Console.WriteLine("Use the arrow keys or WASD to move the cursor.");
            Console.WriteLine("Press Space to draw.");

            Console.WriteLine("\nOther:\n");
            Console.WriteLine("Press P to change your Tool.");
            Console.WriteLine("Press M to switch between the Menu and Drawing mode.");


            Console.WriteLine("\nPress Enter to go back...");
            Console.ReadLine();
        }
    }
}